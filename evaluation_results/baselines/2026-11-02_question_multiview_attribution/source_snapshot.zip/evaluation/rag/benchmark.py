"""Evaluate the frozen corpus with the existing dense/BM25/RRF implementation."""
import argparse
import hashlib
import importlib.metadata
import json
import os
import platform
import shutil
import sys
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]

from app.config import RAG_EMBEDDING_MODEL
from evaluation.rag.dataset import Dataset, checksum
from evaluation.rag.report import build_report
from evaluation.rag.metrics import METRIC_CONTRACT
from evaluation.rag.runner import portable_record, ranking_fingerprint, run_benchmark, write_json
from evaluation.rag.provenance import code_state, model_state


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", type=Path, default=ROOT / "tests/rag_benchmark/dataset/questions.jsonl")
    parser.add_argument("--retriever", choices=["dense", "bm25", "hybrid", "all"], default="hybrid")
    parser.add_argument("--top-k", type=int, default=5)
    parser.add_argument("--ks", type=lambda value: [int(k) for k in value.split(",")], help="Score prefixes of one shared ranking, e.g. 1,3,5,10")
    parser.add_argument("--model", default=RAG_EMBEDDING_MODEL)
    parser.add_argument("--parent-tokens", type=int, default=1600)
    parser.add_argument("--child-tokens", type=int, default=400)
    parser.add_argument("--overlap-tokens", type=int, default=60)
    parser.add_argument("--dense-top-k", type=int, default=20)
    parser.add_argument("--bm25-top-k", type=int, default=20)
    parser.add_argument("--storage-dir", type=Path, default=ROOT / "app/storage/benchmark")
    parser.add_argument("--output-dir", type=Path)
    parser.add_argument("--offline", action="store_true", help="Require previously cached model artifacts")
    parser.add_argument("--require-reviewed", action="store_true", help="Refuse provisional human-unreviewed labels")
    args = parser.parse_args()
    if args.top_k <= 0 or any(k <= 0 for k in (args.ks or [])):
        parser.error("--top-k must be positive")
    if args.offline:
        os.environ["HF_HUB_OFFLINE"] = "1"
        os.environ["TRANSFORMERS_OFFLINE"] = "1"
    os.environ["TOKENIZERS_PARALLELISM"] = "false"
    import numpy as np
    import torch
    from app.rag.retriever import KnowledgeRetriever
    from app.rag.embedder import get_model

    torch.manual_seed(0)
    np.random.seed(0)
    dataset = Dataset(args.dataset, require_reviewed=args.require_reviewed)
    dataset.validate_corpus()
    if dataset.pending_count:
        print(f"PROVISIONAL: {dataset.pending_count} questions still need human review.", flush=True)
    started = time.perf_counter()
    retriever = KnowledgeRetriever(knowledge_dir=dataset.documents_dir, storage_dir=args.storage_dir,
        model_name=args.model, parent_max_tokens=args.parent_tokens, child_max_tokens=args.child_tokens,
        overlap_tokens=args.overlap_tokens, dense_top_k=args.dense_top_k, bm25_top_k=args.bm25_top_k)
    setup_seconds = time.perf_counter() - started
    dataset.validate_index(retriever)
    now = datetime.now(timezone(timedelta(hours=8)))
    output = args.output_dir or ROOT / "evaluation_results" / now.strftime("%Y-%m-%d_%H%M%S_%f")
    output.mkdir(parents=True, exist_ok=False)
    # Keep the original relative dataset layout replayable without editing frozen metadata.
    shutil.copytree(dataset.path.parent, output / "annotation_snapshot")
    shutil.copytree(dataset.documents_dir, output / "documents")
    shutil.copyfile(dataset.manifest_path, output / "manifest.json")
    index_pointer = args.storage_dir / "indexes/current.json"
    pointer = json.loads(index_pointer.read_text(encoding="utf-8"))
    index_dir = index_pointer.parent / pointer["generation"]
    shutil.copytree(index_dir, output / "index_snapshot")
    base = dict(
        schema_version=2, metric_contract=METRIC_CONTRACT, started_at=now.isoformat(), code=code_state(output),
        annotation_status="provisional" if dataset.pending_count else "human-reviewed",
        dataset=dict(version=dataset.metadata["version"], sha256=dataset.sha256,
                     metadata_sha256=checksum(dataset.metadata_path), path=str(dataset.path)),
        corpus=dict(version=dataset.manifest["version"], manifest_sha256=checksum(dataset.manifest_path),
                    documents=dataset.manifest["documents"]),
        embedding=model_state(args.model),
        index=dict(generation=pointer["generation"], pipeline_version=retriever.INDEX_VERSION,
                   signature=pointer["signature"], ocr_enabled=retriever.parser.ocr_enabled,
                   chunks_sha256=checksum(index_dir / "chunks.jsonl"),
                   portable_chunks_sha256=hashlib.sha256(json.dumps([portable_record(r) for r in retriever.store.records],
                       sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode()).hexdigest(), vectors_sha256=checksum(index_dir / "faiss.index"),
                   setup_seconds=setup_seconds, size_bytes=sum(p.stat().st_size for p in index_dir.iterdir() if p.is_file()),
                   documents=len(retriever.documents), parents=len(retriever.parents), children=len(retriever.store.records)),
        chunking=dict(parent_max_tokens=args.parent_tokens, child_max_tokens=args.child_tokens,
                      effective_child_max_tokens=min(args.child_tokens, get_model(args.model).max_seq_length -
                                                     get_model(args.model).tokenizer.num_special_tokens_to_add(pair=False)),
                      overlap_tokens=args.overlap_tokens),
        environment=dict(python=sys.version, platform=platform.platform(), machine=platform.machine(),
                         torch_threads=torch.get_num_threads(), seed=0,
                         dependencies={d.metadata["Name"]: d.version for d in sorted(importlib.metadata.distributions(), key=lambda d: d.metadata["Name"].lower())}),
    )
    strategies = ["dense", "bm25", "hybrid"] if args.retriever == "all" else [args.retriever]
    comparison, had_errors = {}, False
    for strategy in strategies:
        target = output / strategy if args.retriever == "all" else output
        if target != output:
            target.mkdir()
        config = dict(base, retrieval=dict(strategy=strategy, top_k=args.top_k, evaluation_ks=args.ks or [args.top_k], ranking_depth=max([args.top_k, *(args.ks or [])]), dense_top_k=args.dense_top_k,
                bm25_top_k=args.bm25_top_k, candidate_limit_rule="max(configured_top_k, K*4)",
                rrf_rank_constant=60, bm25=dict(type="BM25Plus", k1=retriever.pipeline.sparse.bm25.k1, b=retriever.pipeline.sparse.bm25.b,
                                             delta=retriever.pipeline.sparse.bm25.delta), reranker=False))
        rows = run_benchmark(dataset, retriever, top_k=args.top_k, strategy=strategy, evaluation_ks=args.ks)
        config["ranking_sha256"] = ranking_fingerprint(rows)
        write_json(target / "config.json", config)
        (target / "retrieval_results.jsonl").write_text("".join(json.dumps(r, ensure_ascii=False, allow_nan=False) + "\n" for r in rows), encoding="utf-8")
        metrics = build_report(target, config, rows)
        comparison[strategy] = metrics["overall"]
        had_errors |= metrics["overall"]["errors"] > 0
        print(strategy, json.dumps(metrics["overall"]["child"]), flush=True)
    if args.retriever == "all":
        write_json(output / "comparison.json", comparison)
        lines = ["# Candidate retrieval comparison", "",
                 f"Annotation status: **{base['annotation_status']}**. Do not treat pending labels as human-reviewed acceptance.",
                 "All strategies share the same corpus, index, embedding and chunking configuration.", "",
                 "K is identical, but Child and Parent are separate result universes.", ""]
        for unit in ("child", "parent"):
            lines += [f"## {unit.title()} Retrieval Metrics", "",
                      "| Strategy | Recall@K | Precision@K | MRR@K | NDCG@K |",
                      "| --- | ---: | ---: | ---: | ---: |"]
            for strategy, summary in comparison.items():
                values = [summary[unit][key] for key in ("recall", "precision", "mrr", "ndcg")]
                lines.append(f"| {strategy} | " + " | ".join(f"{value:.4f}" if value is not None else "N/A" for value in values) + " |")
            lines.append("")
        lines += ["", f"K={args.top_k}. Recall is unique evidence coverage within K child or K unique-parent ranks.",
                  "Metric definitions changed from candidate v0.1. Do not interpret score differences as retrieval improvements.",
                  "Precision/NDCG use derived result-level qrels (contract result-qrels-v2); Recall covers unique facts. Unknown cases are excluded.",
                  "Only rank/metric comparisons are meaningful here; sequential strategy order affects cache/latency measurements.",
                  "The exact implementation is archived in source_snapshot.zip; config files record its hash."]
        (output / "comparison.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"Reports: {output.resolve()}")
    if had_errors:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
